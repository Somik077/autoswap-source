package org.funtown.autoswap.screen;

import net.minecraft.class_1657;
import net.minecraft.class_332;
import net.minecraft.class_490;

public class SilentInventoryScreen extends class_490 {

    public SilentInventoryScreen(class_1657 player) {
        super(player);
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    @Override
    public boolean method_25422() {
        return false;
    }
}