package org.funtown.autoswap.screen;

import org.lwjgl.glfw.GLFW;

import java.util.*;
import java.util.function.Consumer;
import java.util.stream.Collectors;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_3532;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_7923;

public class ItemPickerScreen extends class_437 {

    private static final int CELL = 18;
    private static final int COLS = 12;
    private static final int PAD  = 8;

    private final class_437         parent;
    private final Consumer<class_1792> callback;
    private class_342      searchField;
    private final List<class_1792>     allItems;
    private List<class_1792>           filtered;
    private int                  scrollRow = 0;
    private class_1792                 hoveredItem = null;

    public ItemPickerScreen(class_437 parent, Consumer<class_1792> callback) {
        super(class_2561.method_43471("autoswap.screen.picker.title"));
        this.parent   = parent;
        this.callback = callback;
        allItems = new ArrayList<>();
        class_7923.field_41178.forEach(item -> { if (item != class_1802.field_8162) allItems.add(item); });
        allItems.sort((a, b) -> a.method_63680().getString().compareToIgnoreCase(b.method_63680().getString()));
        filtered = new ArrayList<>(allItems);
    }

    @Override
    protected void method_25426() {
        searchField = new class_342(field_22793,
                field_22789 / 2 - 110, PAD + 16, 220, 20,
                class_2561.method_43471("autoswap.screen.picker.search"));
        searchField.method_1880(64);
        searchField.method_47404(class_2561.method_43471("autoswap.screen.picker.search"));
        searchField.method_1863(q -> {
            scrollRow = 0;
            String query = q.trim().toLowerCase(Locale.ROOT);
            filtered = query.isEmpty() ? new ArrayList<>(allItems) :
                    allItems.stream().filter(item ->
                            item.method_63680().getString().toLowerCase(Locale.ROOT).contains(query) ||
                                    class_7923.field_41178.method_10221(item).toString().toLowerCase(Locale.ROOT).contains(query)
                    ).collect(Collectors.toList());
        });
        method_37063(searchField);
        method_48265(searchField);

        method_37063(class_4185.method_46430(
                class_2561.method_43471("autoswap.screen.picker.cancel"),
                btn -> field_22787.method_1507(parent)
        ).method_46434(field_22789 / 2 - 50, field_22790 - PAD - 20, 100, 20).method_46431());
    }

    @Override
    public void method_25394(class_332 ctx, int mouseX, int mouseY, float delta) {
        method_25420(ctx, mouseX, mouseY, delta);
        super.method_25394(ctx, mouseX, mouseY, delta);
        ctx.method_27534(field_22793, field_22785, field_22789 / 2, PAD, 0xFFFFFF);

        int gridX      = (field_22789 - COLS * CELL) / 2;
        int gridTop    = PAD + 16 + 20 + PAD;
        int gridBottom = field_22790 - PAD - 20 - PAD;
        int visRows    = (gridBottom - gridTop) / CELL;
        hoveredItem    = null;

        for (int row = 0; row < visRows; row++) {
            for (int col = 0; col < COLS; col++) {
                int idx = (scrollRow + row) * COLS + col;
                if (idx >= filtered.size()) break;
                class_1792 item = filtered.get(idx);
                int  ix   = gridX + col * CELL;
                int  iy   = gridTop + row * CELL;
                boolean hov = mouseX >= ix && mouseX < ix + CELL && mouseY >= iy && mouseY < iy + CELL;
                if (hov) { ctx.method_25294(ix, iy, ix + CELL, iy + CELL, 0x60FFFFFF); hoveredItem = item; }
                ctx.method_51427(item.method_7854(), ix + 1, iy + 1);
            }
        }
        if (hoveredItem != null) ctx.method_51438(field_22793, hoveredItem.method_63680(), mouseX, mouseY);

        
        if (maxScrollRow() > 0) {
            int totalRows = (filtered.size() + COLS - 1) / COLS;
            int barH = Math.max(10, (gridBottom - gridTop) * visRows / totalRows);
            int barY = gridTop + (gridBottom - gridTop - barH) * scrollRow / maxScrollRow();
            ctx.method_25294(field_22789 - 6, gridTop, field_22789 - 2, gridBottom, 0x40FFFFFF);
            ctx.method_25294(field_22789 - 6, barY, field_22789 - 2, barY + barH, 0xAAFFFFFF);
        }
    }

    @Override
    public boolean method_25402(double mx, double my, int button) {
        if (super.method_25402(mx, my, button)) return true;
        int gridX = (field_22789 - COLS * CELL) / 2, gridTop = PAD + 16 + 20 + PAD;
        int gridBottom = field_22790 - PAD - 20 - PAD, visRows = (gridBottom - gridTop) / CELL;
        for (int row = 0; row < visRows; row++) for (int col = 0; col < COLS; col++) {
            int idx = (scrollRow + row) * COLS + col; if (idx >= filtered.size()) break;
            int ix = gridX + col * CELL, iy = gridTop + row * CELL;
            if (mx >= ix && mx < ix + CELL && my >= iy && my < iy + CELL) {
                callback.accept(filtered.get(idx)); field_22787.method_1507(parent); return true;
            }
        }
        return false;
    }

    @Override
    public boolean method_25401(double mx, double my, double h, double v) {
        scrollRow = class_3532.method_15340(scrollRow - (int) Math.signum(v), 0, maxScrollRow());
        return true;
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_ESCAPE) { field_22787.method_1507(parent); return true; }
        return super.method_25404(keyCode, scanCode, modifiers);
    }

    private int maxScrollRow() {
        int gt = PAD + 16 + 20 + PAD, gb = field_22790 - PAD - 20 - PAD, vr = (gb - gt) / CELL;
        return Math.max(0, (filtered.size() + COLS - 1) / COLS - vr);
    }
}