package org.funtown.autoswap.screen;

import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import org.funtown.autoswap.config.AutoSwapConfig;
import org.funtown.autoswap.config.AutoSwapSettings;
import org.funtown.autoswap.config.ModTranslation;

public class SettingsScreen extends class_437 {

    private final class_437 parent;
    private AutoSwapSettings s;
    private class_4185 actionBarBtn;
    private class_4185 langBtn;

    private static final int[] COOLDOWN_STEPS = {0, 100, 200, 300, 500, 750, 1000};

    public SettingsScreen(class_437 parent) {
        super(ModTranslation.t("autoswap.screen.settings.title"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        s = AutoSwapConfig.getInstance().settings;

        int cx = field_22789 / 2, y0 = field_22790 / 2 - 80, row = 38;

        
        method_37063(class_4185.method_46430(class_2561.method_43470("◀"), btn -> {
            s.inventoryOpenDelayTicks = Math.max(1, s.inventoryOpenDelayTicks - 1);
            AutoSwapConfig.save();
        }).method_46434(cx - 60, y0 + 16, 20, 20).method_46431());

        method_37063(class_4185.method_46430(class_2561.method_43470("▶"), btn -> {
            s.inventoryOpenDelayTicks = Math.min(10, s.inventoryOpenDelayTicks + 1);
            AutoSwapConfig.save();
        }).method_46434(cx + 40, y0 + 16, 20, 20).method_46431());

        
        method_37063(class_4185.method_46430(class_2561.method_43470("◀"), btn -> {
            s.swapCooldownMs = prevStep(s.swapCooldownMs);
            AutoSwapConfig.save();
        }).method_46434(cx - 60, y0 + row + 16, 20, 20).method_46431());

        method_37063(class_4185.method_46430(class_2561.method_43470("▶"), btn -> {
            s.swapCooldownMs = nextStep(s.swapCooldownMs);
            AutoSwapConfig.save();
        }).method_46434(cx + 40, y0 + row + 16, 20, 20).method_46431());

        
        actionBarBtn = class_4185.method_46430(actionBarLabel(), btn -> {
            s.showActionBar = !s.showActionBar;
            actionBarBtn.method_25355(actionBarLabel());
            AutoSwapConfig.save();
        }).method_46434(cx - 60, y0 + row * 2 + 14, 120, 20).method_46431();
        method_37063(actionBarBtn);

        
        langBtn = class_4185.method_46430(langLabel(), btn -> {
            
            String newLang = isRu() ? "en_us" : "ru_ru";
            s.language = newLang;
            AutoSwapConfig.save();
            ModTranslation.load(newLang);
            
            method_41843();
            
            if (parent instanceof AutoSwapConfigScreen cfg) cfg.refresh();
        }).method_46434(cx - 60, y0 + row * 3 + 12, 120, 20).method_46431();
        method_37063(langBtn);

        
        method_37063(class_4185.method_46430(
                ModTranslation.t("autoswap.screen.settings.done"),
                btn -> method_25419()
        ).method_46434(cx - 50, y0 + row * 4 + 14, 100, 20).method_46431());
    }

    @Override
    public void method_25394(class_332 ctx, int mouseX, int mouseY, float delta) {
        method_25420(ctx, mouseX, mouseY, delta);
        super.method_25394(ctx, mouseX, mouseY, delta);

        int cx = field_22789 / 2, y0 = field_22790 / 2 - 80, row = 38;

        ctx.method_27534(field_22793,
                ModTranslation.t("autoswap.screen.settings.title"), cx, y0 - 10, 0xFFFFFF);

        
        ctx.method_27534(field_22793,
                ModTranslation.t("autoswap.screen.settings.delay"), cx, y0 + 4, 0xAAAAAA);
        ctx.method_27534(field_22793,
                class_2561.method_43470(s.inventoryOpenDelayTicks + " tick(s)"), cx, y0 + 20, 0xFFFFFF);

        
        ctx.method_27534(field_22793,
                ModTranslation.t("autoswap.screen.settings.cooldown"), cx, y0 + row + 4, 0xAAAAAA);
        ctx.method_27534(field_22793,
                class_2561.method_43470(s.swapCooldownMs + " ms"), cx, y0 + row + 20, 0xFFFFFF);
    }

    @Override
    public void method_25419() {
        AutoSwapConfig.save();
        assert field_22787 != null;
        field_22787.method_1507(parent);
    }

    

    private boolean isRu() { return "ru_ru".equals(s.language); }

    private class_2561 actionBarLabel() {
        return isActionBarOn()
                ? ModTranslation.t("autoswap.screen.settings.actionbar_on").method_27661().method_27692(class_124.field_1060)
                : ModTranslation.t("autoswap.screen.settings.actionbar_off").method_27661().method_27692(class_124.field_1080);
    }
    private boolean isActionBarOn() { return s.showActionBar; }

    private class_2561 langLabel() {
        return isRu()
                ? class_2561.method_43470("🌐 English").method_27692(class_124.field_1075)
                : class_2561.method_43470("🌐 Русский").method_27692(class_124.field_1075);
    }

    private int nextStep(int cur) {
        for (int v : COOLDOWN_STEPS) if (v > cur) return v;
        return COOLDOWN_STEPS[COOLDOWN_STEPS.length - 1];
    }
    private int prevStep(int cur) {
        for (int i = COOLDOWN_STEPS.length - 1; i >= 0; i--)
            if (COOLDOWN_STEPS[i] < cur) return COOLDOWN_STEPS[i];
        return 0;
    }
}