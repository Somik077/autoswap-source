package org.funtown.autoswap.screen;

import org.funtown.autoswap.config.AutoSwapConfig;
import org.funtown.autoswap.config.ModTranslation;
import org.funtown.autoswap.config.SwapEntry;
import org.funtown.autoswap.config.SwapPair;
import org.funtown.autoswap.swap.SlotDetector;

import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_350;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_6382;
import net.minecraft.class_7923;

public class EditSwapScreen extends class_437 {

    private final class_437    parent;
    private final SwapEntry entry;
    private class_342 labelField;
    private PairListWidget  pairList;

    public EditSwapScreen(class_437 parent, SwapEntry entry) {
        super(ModTranslation.t("autoswap.screen.edit.title"));
        this.parent = parent;
        this.entry  = entry;
    }

    @Override
    protected void method_25426() {
        String currentLabel = entry.label.equals("autoswap.entry.default_label")
                ? "" : entry.label;

        labelField = new class_342(field_22793,
                field_22789 / 2 - 110, 18, 220, 20,
                ModTranslation.t("autoswap.screen.edit.label_placeholder"));
        labelField.method_1852(currentLabel);
        labelField.method_1880(40);
        labelField.method_47404(ModTranslation.t("autoswap.screen.edit.label_placeholder")
                .method_27661().method_27692(class_124.field_1063));
        labelField.method_1863(text -> {
            entry.label = text.isEmpty() ? "autoswap.entry.default_label" : text;
            AutoSwapConfig.save();
        });
        method_37063(labelField);

        pairList = new PairListWidget(field_22787, field_22789, field_22790 - 80, 48, 44);
        method_37063(pairList);

        method_37063(class_4185.method_46430(
                ModTranslation.t("autoswap.screen.edit.add_pair"),
                btn -> {
                    entry.pairs.add(new SwapPair());
                    AutoSwapConfig.save();
                    pairList.reload();
                }
        ).method_46434(field_22789 / 2 - 102, field_22790 - 28, 100, 20).method_46431());

        method_37063(class_4185.method_46430(
                ModTranslation.t("autoswap.screen.edit.done"),
                btn -> method_25419()
        ).method_46434(field_22789 / 2 + 2, field_22790 - 28, 100, 20).method_46431());
    }

    @Override
    public void method_25394(class_332 ctx, int mouseX, int mouseY, float delta) {
        method_25420(ctx, mouseX, mouseY, delta);
        super.method_25394(ctx, mouseX, mouseY, delta);
        ctx.method_27534(field_22793, field_22785, field_22789 / 2, 6, 0xFFFFFF);
        if (entry.pairs.isEmpty())
            ctx.method_27534(field_22793,
                    ModTranslation.t("autoswap.screen.edit.empty"),
                    field_22789 / 2, field_22790 / 2 - 8, 0x888888);
    }

    @Override
    public void method_25419() {
        AutoSwapConfig.save();
        assert field_22787 != null;
        field_22787.method_1507(parent);
    }

    

    class PairListWidget extends class_350<PairListWidget.PairRow> {

        PairListWidget(class_310 mc, int w, int h, int top, int itemH) {
            super(mc, w, h, top, itemH);
            reload();
        }

        @Override public void method_47399(class_6382 b) {}

        void reload() {
            method_25339();
            for (int i = 0; i < entry.pairs.size(); i++)
                method_25321(new PairRow(entry.pairs.get(i), i));
        }

        @Override public int method_25322() { return Math.min(field_22758 - 20, 500); }

        class PairRow extends class_350.class_351<PairRow> {

            private final SwapPair pair;
            private final int      pairIndex;

            private class_4185 itemABtn;
            private class_4185 itemBBtn;
            private class_4185 slotBtn;
            private final class_4185 deleteBtn;

            PairRow(SwapPair pair, int pairIndex) {
                this.pair      = pair;
                this.pairIndex = pairIndex;

                itemABtn = class_4185.method_46430(
                        class_2561.method_43470(pair.getItemAName()),
                        btn -> field_22740.method_1507(new ItemPickerScreen(
                                EditSwapScreen.this,
                                item -> {
                                    pair.itemId = class_7923.field_41178.method_10221(item).toString();
                                    
                                    pair.targetSlot = SlotDetector.detectSlot(item);
                                    itemABtn.method_25355(class_2561.method_43470(pair.getItemAName()));
                                    slotBtn.method_25355(class_2561.method_43470(pair.targetSlot.getDisplayName()));
                                    AutoSwapConfig.save();
                                }))
                ).method_46437(100, 20).method_46431();

                itemBBtn = class_4185.method_46430(
                        class_2561.method_43470(pair.getItemBName()),
                        btn -> field_22740.method_1507(new ItemPickerScreen(
                                EditSwapScreen.this,
                                item -> {
                                    pair.itemId2 = class_7923.field_41178.method_10221(item).toString();
                                    
                                    pair.targetSlot = SlotDetector.detectSlot(item);
                                    itemBBtn.method_25355(class_2561.method_43470(pair.getItemBName()));
                                    slotBtn.method_25355(class_2561.method_43470(pair.targetSlot.getDisplayName()));
                                    AutoSwapConfig.save();
                                }))
                ).method_46437(100, 20).method_46431();

                slotBtn = class_4185.method_46430(
                        class_2561.method_43470(pair.targetSlot.getDisplayName()),
                        btn -> {
                            pair.targetSlot = pair.targetSlot.next();
                            slotBtn.method_25355(class_2561.method_43470(pair.targetSlot.getDisplayName()));
                            AutoSwapConfig.save();
                        }
                ).method_46437(82, 20).method_46431();

                deleteBtn = class_4185.method_46430(
                        class_2561.method_43470("✕").method_27692(class_124.field_1061),
                        btn -> {
                            entry.pairs.remove(pairIndex);
                            AutoSwapConfig.save();
                            pairList.reload();
                        }
                ).method_46437(20, 20).method_46431();
            }

            @Override
            public void render(class_332 ctx, int index, int y, int x,
                               int ew, int eh, int mx, int my, boolean hov, float d) {
                int midY  = y + (eh - 20) / 2;
                int iconY = y + (eh - 16) / 2;

                if (hov) ctx.method_25294(x, y, x + ew, y + eh, 0x18FFFFFF);

                
                safeDrawItem(ctx, pair.itemId, x + 2, iconY);
                itemABtn.method_48229(x + 21, midY);
                itemABtn.method_25394(ctx, mx, my, d);

                int p2 = x + 21 + 100 + 4;
                ctx.method_27535(field_22740.field_1772,
                        class_2561.method_43470("↔"), p2, midY + 5, 0xAAAAAA);

                
                int bx = p2 + 13;
                safeDrawItem(ctx, pair.itemId2, bx, iconY);
                itemBBtn.method_48229(bx + 19, midY);
                itemBBtn.method_25394(ctx, mx, my, d);

                int p3 = bx + 19 + 100 + 4;
                ctx.method_27535(field_22740.field_1772,
                        class_2561.method_43470("→"), p3, midY + 5, 0x888888);

                slotBtn.method_48229(p3 + 12, midY);
                slotBtn.method_25394(ctx, mx, my, d);

                deleteBtn.method_48229(x + ew - 24, midY);
                deleteBtn.method_25394(ctx, mx, my, d);
            }
            private void safeDrawItem(class_332 ctx, String itemId, int x, int y) {
                if (field_22740.field_1724 == null) {
                    ctx.method_25294(x, y, x + 16, y + 16, 0x44AAAAAA);
                    return;
                }
                try {
                    ctx.method_51427(
                            new class_1799(class_7923.field_41178.method_63535(class_2960.method_60654(itemId))), x, y);
                } catch (Exception ignored) {}
            }

            @Override
            public boolean mouseClicked(double mx, double my, int btn) {
                for (var c : children()) if (c.method_25402(mx, my, btn)) return true;
                return false;
            }
            public List<? extends net.minecraft.class_364> children() {
                return List.of(itemABtn, itemBBtn, slotBtn, deleteBtn);
            }
            public List<? extends net.minecraft.class_6379> selectableChildren() {
                return List.of(itemABtn, itemBBtn, slotBtn, deleteBtn);
            }
            public void appendNarrations(class_6382 b) {}
        }
    }
}