package org.funtown.autoswap.screen;

import org.funtown.autoswap.config.AutoSwapConfig;
import org.funtown.autoswap.config.ModTranslation;
import org.funtown.autoswap.config.Profile;
import org.funtown.autoswap.config.SwapEntry;
import org.lwjgl.glfw.GLFW;

import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_350;
import net.minecraft.class_3675;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_6382;

public class AutoSwapConfigScreen extends class_437 {

    private final class_437   parent;
    private SwapListWidget swapList;

    SwapEntry    keyBindTarget = null;
    class_4185 keyBindButton = null;

    private static final int TAB_Y    = 28;
    private static final int TAB_H    = 18;
    private static final int LIST_TOP = TAB_Y + TAB_H + 4;

    public AutoSwapConfigScreen(class_437 parent) {
        super(ModTranslation.t("autoswap.screen.config.title"));
        this.parent = parent;
    }

    public void refresh() {
        method_41843();
    }

    void startKeyBind(SwapEntry entry, class_4185 btn) {
        if (keyBindTarget != null)
            keyBindButton.method_25355(class_2561.method_43470(keyBindTarget.getKeyDisplayName()));
        keyBindTarget = entry;
        keyBindButton = btn;
        btn.method_25355(ModTranslation.t("autoswap.screen.config.press_key")
                .method_27661().method_27692(class_124.field_1054));
    }

    @Override
    protected void method_25426() {
        swapList = new SwapListWidget(field_22787, field_22789, field_22790 - LIST_TOP - 30, LIST_TOP, 32);
        method_37063(swapList);

        method_37063(class_4185.method_46430(
                ModTranslation.t("autoswap.screen.config.add"),
                btn -> {
                    AutoSwapConfig.getInstance().getEntries().add(new SwapEntry());
                    AutoSwapConfig.save();
                    swapList.reload();
                }
        ).method_46434(field_22789 / 2 - 156, field_22790 - 24, 100, 20).method_46431());

        method_37063(class_4185.method_46430(
                ModTranslation.t("autoswap.screen.config.settings"),
                btn -> field_22787.method_1507(new SettingsScreen(this))
        ).method_46434(field_22789 / 2 - 50, field_22790 - 24, 100, 20).method_46431());

        method_37063(class_4185.method_46430(
                ModTranslation.t("autoswap.screen.config.done"),
                btn -> method_25419()
        ).method_46434(field_22789 / 2 + 56, field_22790 - 24, 100, 20).method_46431());
    }

    

    private int tabWidth() {
        int count = AutoSwapConfig.getInstance().profiles.size() + 1;
        return Math.min(80, (field_22789 - 20) / Math.max(count, 1));
    }
    private int tabStartX(int i) {
        int tw = tabWidth();
        int total = AutoSwapConfig.getInstance().profiles.size() + 1;
        return (field_22789 - tw * total) / 2 + i * tw;
    }

    @Override
    public void method_25394(class_332 ctx, int mx, int my, float delta) {
        method_25420(ctx, mx, my, delta);
        super.method_25394(ctx, mx, my, delta);
        ctx.method_27534(field_22793,
                ModTranslation.t("autoswap.screen.config.title"), field_22789 / 2, 10, 0xFFFFFF);

        List<Profile> profiles = AutoSwapConfig.getInstance().profiles;
        int active = AutoSwapConfig.getInstance().activeProfile;
        int tw     = tabWidth();

        for (int i = 0; i < profiles.size(); i++) {
            int tx  = tabStartX(i);
            boolean sel = (i == active);
            ctx.method_25294(tx + 1, TAB_Y, tx + tw - 1, TAB_Y + TAB_H,
                    sel ? 0xCC5588CC : 0x88333333);
            String name = profiles.get(i).name;
            if (name.length() > 9) name = name.substring(0, 8) + "…";
            ctx.method_27534(field_22793, class_2561.method_43470(name),
                    tx + tw / 2, TAB_Y + 4, sel ? 0xFFFFFF : 0xAAAAAA);
            if (!sel && mx >= tx && mx < tx + tw && my >= TAB_Y && my < TAB_Y + TAB_H)
                ctx.method_25294(tx + 1, TAB_Y, tx + tw - 1, TAB_Y + TAB_H, 0x30FFFFFF);
            if (sel && profiles.size() > 1)
                ctx.method_27535(field_22793,
                        class_2561.method_43470("✕").method_27692(class_124.field_1061),
                        tx + tw - 11, TAB_Y + 4, 0xFF5555);
        }

        int addX = tabStartX(profiles.size());
        ctx.method_25294(addX + 1, TAB_Y, addX + tw - 1, TAB_Y + TAB_H, 0x88333333);
        ctx.method_27534(field_22793,
                class_2561.method_43470("+").method_27692(class_124.field_1060),
                addX + tw / 2, TAB_Y + 4, 0x55FF55);

        if (AutoSwapConfig.getInstance().getEntries().isEmpty())
            ctx.method_27534(field_22793,
                    ModTranslation.t("autoswap.screen.config.empty"),
                    field_22789 / 2, field_22790 / 2 - 8, 0x666666);
    }

    @Override
    public boolean method_25402(double mx, double my, int btn) {
        if (my >= TAB_Y && my < TAB_Y + TAB_H) {
            List<Profile> profiles = AutoSwapConfig.getInstance().profiles;
            int tw = tabWidth();

            int addX = tabStartX(profiles.size());
            if (mx >= addX && mx < addX + tw) {
                profiles.add(new Profile("Profile " + (profiles.size() + 1)));
                AutoSwapConfig.getInstance().activeProfile = profiles.size() - 1;
                AutoSwapConfig.save();
                swapList.reload();
                return true;
            }
            for (int i = 0; i < profiles.size(); i++) {
                int tx = tabStartX(i);
                if (mx >= tx && mx < tx + tw) {
                    int active = AutoSwapConfig.getInstance().activeProfile;
                    if (i == active && profiles.size() > 1 && mx >= tx + tw - 14) {
                        profiles.remove(i);
                        AutoSwapConfig.getInstance().activeProfile = Math.max(0, active - 1);
                        AutoSwapConfig.save();
                        swapList.reload();
                        return true;
                    }
                    AutoSwapConfig.getInstance().activeProfile = i;
                    AutoSwapConfig.save();
                    swapList.reload();
                    return true;
                }
            }
        }
        return super.method_25402(mx, my, btn);
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (keyBindTarget != null) {
            if (keyCode != GLFW.GLFW_KEY_ESCAPE) {
                class_3675.class_306 key = class_3675.method_15985(keyCode, scanCode);
                keyBindTarget.keyName = key.method_1441();
                keyBindButton.method_25355(class_2561.method_43470(keyBindTarget.getKeyDisplayName()));
                AutoSwapConfig.save();
            } else {
                keyBindButton.method_25355(class_2561.method_43470(keyBindTarget.getKeyDisplayName()));
            }
            keyBindTarget = null;
            keyBindButton = null;
            return true;
        }
        return super.method_25404(keyCode, scanCode, modifiers);
    }

    @Override
    public void method_25419() {
        AutoSwapConfig.save();
        assert field_22787 != null;
        field_22787.method_1507(parent);
    }

    

    class SwapListWidget extends class_350<SwapListWidget.EntryRow> {

        SwapListWidget(class_310 mc, int w, int h, int top, int itemH) {
            super(mc, w, h, top, itemH);
            reload();
        }

        @Override public void method_47399(class_6382 b) {}

        void reload() {
            method_25339();
            List<SwapEntry> entries = AutoSwapConfig.getInstance().getEntries();
            for (int i = 0; i < entries.size(); i++)
                method_25321(new EntryRow(entries.get(i), i));
        }

        @Override public int method_25322() { return Math.min(field_22758 - 20, 400); }

        class EntryRow extends class_350.class_351<EntryRow> {

            private final SwapEntry entry;
            private final int       idx;
            private       class_4185 keyBtn;
            private final class_4185 editBtn;
            private final class_4185 deleteBtn;

            EntryRow(SwapEntry entry, int idx) {
                this.entry = entry;
                this.idx   = idx;

                keyBtn = class_4185.method_46430(
                        class_2561.method_43470(entry.getKeyDisplayName()),
                        btn -> AutoSwapConfigScreen.this.startKeyBind(entry, keyBtn)
                ).method_46437(70, 20).method_46431();

                editBtn = class_4185.method_46430(
                        ModTranslation.t("autoswap.screen.config.edit"),
                        btn -> field_22740.method_1507(new EditSwapScreen(AutoSwapConfigScreen.this, entry))
                ).method_46437(60, 20).method_46431();

                deleteBtn = class_4185.method_46430(
                        class_2561.method_43470("✕").method_27692(class_124.field_1061),
                        btn -> {
                            AutoSwapConfig.getInstance().getEntries().remove(idx);
                            AutoSwapConfig.save();
                            swapList.reload();
                        }
                ).method_46437(20, 20).method_46431();
            }

            @Override
            public void render(class_332 ctx, int index, int y, int x,
                               int ew, int eh, int mx, int my, boolean hov, float d) {
                int midY = y + (eh - 20) / 2;
                if (hov) ctx.method_25294(x, y, x + ew, y + eh, 0x18FFFFFF);

                String label = entry.getDisplayLabel();
                ctx.method_27535(field_22740.field_1772,
                        class_2561.method_43470(label).method_27692(
                                entry.pairs.isEmpty() ? class_124.field_1080 : class_124.field_1068),
                        x + 4, midY + 5, 0xFFFFFF);

                int count = entry.pairs.size();
                if (count == 0)
                    ctx.method_27535(field_22740.field_1772,
                            ModTranslation.t("autoswap.screen.config.no_pairs")
                                    .method_27661().method_27692(class_124.field_1079),
                            x + 4 + field_22793.method_1727(label) + 2, midY + 5, 0xFF5555);
                else if (count > 1)
                    ctx.method_27535(field_22740.field_1772,
                            class_2561.method_43470(" (" + count + ")").method_27692(class_124.field_1063),
                            x + 4 + field_22793.method_1727(label), midY + 5, 0x666666);

                deleteBtn.method_48229(x + ew - 24, midY);
                editBtn.method_48229(x + ew - 88, midY);
                keyBtn.method_48229(x + ew - 162, midY);
                keyBtn.method_25394(ctx, mx, my, d);
                editBtn.method_25394(ctx, mx, my, d);
                deleteBtn.method_25394(ctx, mx, my, d);
            }

            @Override
            public boolean mouseClicked(double mx, double my, int btn) {
                for (var c : children()) if (c.method_25402(mx, my, btn)) return true;
                return false;
            }
            public List<? extends net.minecraft.class_364> children() {
                return List.of(keyBtn, editBtn, deleteBtn);
            }
            public List<? extends net.minecraft.class_6379> selectableChildren() {
                return List.of(keyBtn, editBtn, deleteBtn);
            }
            public void appendNarrations(class_6382 b) {}
        }
    }
}