package org.funtown.autoswap.config;

import net.minecraft.class_1792;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import org.funtown.autoswap.swap.TargetSlot;

public class SwapPair {

    public String     itemId     = "minecraft:air";
    public String     itemId2    = "minecraft:air";
    public TargetSlot targetSlot = TargetSlot.CHESTPLATE;

    

    public String getItemAName() { return displayName(itemId); }
    public String getItemBName() { return displayName(itemId2); }

    private static String displayName(String id) {
        if (id == null || id.isEmpty() || "minecraft:air".equals(id)) return "Select...";
        try {
            class_1792 item = class_7923.field_41178.method_63535(class_2960.method_60654(id));
            String name = item.method_63680().getString();
            return name.length() > 14 ? name.substring(0, 13) + "…" : name;
        } catch (Exception e) { return id; }
    }
}