package org.funtown.autoswap.config;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_3675;

public class SwapEntry {

    public String         label   = "autoswap.entry.default_label"; 
    public List<SwapPair> pairs   = new ArrayList<>();
    public String         keyName = "key.keyboard.unknown";

    private transient boolean prevPressed = false;

    

    public boolean wasJustPressed(class_310 client) {
        if ("key.keyboard.unknown".equals(keyName)) { prevPressed = false; return false; }
        class_3675.class_306 key = class_3675.method_15981(keyName);
        if (key.equals(class_3675.field_16237)) { prevPressed = false; return false; }
        boolean pressed     = class_3675.method_15987(client.method_22683().method_4490(), key.method_1444());
        boolean justPressed = pressed && !prevPressed;
        prevPressed         = pressed;
        return justPressed;
    }

    

    public String getKeyDisplayName() {
        if ("key.keyboard.unknown".equals(keyName))
            return class_2561.method_43471("autoswap.key.unbound").getString();
        class_3675.class_306 key = class_3675.method_15981(keyName);
        if (key.equals(class_3675.field_16237))
            return class_2561.method_43471("autoswap.key.unbound").getString();
        return key.method_27445().getString();
    }

    public String getDisplayLabel() {
        String def = class_2561.method_43471("autoswap.entry.default_label").getString();
        boolean isDefault = label.equals("autoswap.entry.default_label") || label.equals(def);
        if (isDefault && !pairs.isEmpty()) {
            SwapPair p = pairs.get(0);
            return p.getItemAName() + " ↔ " + p.getItemBName();
        }
        return isDefault ? def : label;
    }
}