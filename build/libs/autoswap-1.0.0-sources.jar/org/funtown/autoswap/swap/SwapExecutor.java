package org.funtown.autoswap.swap;

import org.funtown.autoswap.config.AutoSwapConfig;
import org.funtown.autoswap.config.AutoSwapSettings;
import org.funtown.autoswap.config.SwapEntry;
import org.funtown.autoswap.config.SwapPair;
import org.funtown.autoswap.hud.SwapHud;
import org.funtown.autoswap.screen.SilentInventoryScreen;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1661;
import net.minecraft.class_1713;
import net.minecraft.class_1723;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_490;
import net.minecraft.class_7923;

public class SwapExecutor {

    private enum State { IDLE, OPEN_SCREEN, WAITING, EXECUTE }

    private static State           state        = State.IDLE;
    private static List<SwapEntry> pending      = new ArrayList<>();
    private static int             ticksWaited  = 0;
    private static long            lastSwapTime = 0L;
    public static void schedule(List<SwapEntry> entries) {
        if (state != State.IDLE || entries.isEmpty()) return;
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null) return;
        AutoSwapSettings s = AutoSwapConfig.getInstance().settings;
        if (System.currentTimeMillis() - lastSwapTime < s.swapCooldownMs) return;
        pending = new ArrayList<>(entries);
        state   = State.OPEN_SCREEN;
    }

    public static void tick(class_310 client) {
        if (state == State.IDLE || client.field_1724 == null) return;

        switch (state) {
            case OPEN_SCREEN -> {
                if (isSourceInHotbar(client, pending)) {
                    client.method_1507(new SilentInventoryScreen(client.field_1724));
                } else {
                    client.method_1507(new class_490(client.field_1724));
                }
                ticksWaited = 0;
                state = State.WAITING;
            }
            case WAITING -> {
                int delay = AutoSwapConfig.getInstance().settings.inventoryOpenDelayTicks;
                if (++ticksWaited < Math.max(1, delay)) return;
                state = State.EXECUTE;
            }
            case EXECUTE -> {
                try { executePending(client); }
                finally {
                    client.method_1507(null);
                    pending.clear();
                    lastSwapTime = System.currentTimeMillis();
                    state = State.IDLE;
                }
            }
        }
    }

    private static boolean isSourceInHotbar(class_310 client,
                                            List<SwapEntry> entries) {
        class_1661     inv     = client.field_1724.method_31548();
        class_1723 handler = client.field_1724.field_7498;

        for (SwapEntry entry : entries) {
            for (SwapPair pair : entry.pairs) {
                class_1792 itemA = resolve(pair.itemId);
                class_1792 itemB = resolve(pair.itemId2);
                if (itemA == null && itemB == null) continue;

                class_1799 inSlot = handler.method_7611(pair.targetSlot.screenSlot).method_7677();
                boolean   aOn    = itemA != null && !inSlot.method_7960() && inSlot.method_31574(itemA);
                boolean   bOn    = itemB != null && !inSlot.method_7960() && inSlot.method_31574(itemB);

                int srcInv = -1;
                if (aOn)      { if (itemB != null) srcInv = findSlot(inv, itemB); }
                else if (bOn) { if (itemA != null) srcInv = findSlot(inv, itemA); }
                else {
                    if (itemA != null) srcInv = findSlot(inv, itemA);
                    if (srcInv == -1 && itemB != null) srcInv = findSlot(inv, itemB);
                }

                if (srcInv >= 9) return false;
            }
        }
        return true;
    }

    private static void executePending(class_310 client) {
        class_1723 handler = client.field_1724.field_7498;
        int syncId = handler.field_7763;

        List<class_1799> equippedIcons = new ArrayList<>();
        List<String>    equippedNames = new ArrayList<>();

        for (SwapEntry entry : pending) {
            for (SwapPair pair : entry.pairs) {
                PairResult result = processPair(client, pair, handler, syncId);
                if (result != null) {
                    equippedIcons.add(result.icon());
                    equippedNames.add(result.name());
                }
            }
        }

        if (!equippedIcons.isEmpty()
                && AutoSwapConfig.getInstance().settings.showActionBar) {
            SwapHud.showSuccess(equippedIcons, equippedNames);
        }
    }

    private record PairResult(class_1799 icon, String name) {}

    private static PairResult processPair(class_310 client, SwapPair pair,
                                          class_1723 handler, int syncId) {
        class_1792 itemA = resolve(pair.itemId);
        class_1792 itemB = resolve(pair.itemId2);
        if (itemA == null && itemB == null) return null;

        class_1661 inv     = client.field_1724.method_31548();
        int             tgtSlot = pair.targetSlot.screenSlot;
        class_1799       inSlot  = handler.method_7611(tgtSlot).method_7677();

        boolean aOn = itemA != null && !inSlot.method_7960() && inSlot.method_31574(itemA);
        boolean bOn = itemB != null && !inSlot.method_7960() && inSlot.method_31574(itemB);

        int  srcInv  = -1;
        class_1792 toEquip = null;

        if (aOn) {
            if (itemB == null) return null;
            srcInv  = findSlot(inv, itemB);
            toEquip = itemB;
            if (srcInv == -1) {
                SwapHud.showNotFound(itemB.method_63680().getString());
                return null;
            }

        } else if (bOn) {
            if (itemA == null) return null;
            srcInv  = findSlot(inv, itemA);
            toEquip = itemA;
            if (srcInv == -1) {
                SwapHud.showNotFound(itemA.method_63680().getString());
                return null;
            }

        } else {
            if (itemA != null) { srcInv = findSlot(inv, itemA); toEquip = itemA; }
            if (srcInv == -1 && itemB != null) { srcInv = findSlot(inv, itemB); toEquip = itemB; }
            if (srcInv == -1) {
                String missingName = itemA != null
                        ? itemA.method_63680().getString()
                        : itemB.method_63680().getString();
                SwapHud.showNotFound(missingName);
                return null;
            }
        }

        int srcScreen = invToScreen(srcInv);

        if (pair.targetSlot == TargetSlot.OFFHAND) {
            client.field_1761.method_2906(syncId, srcScreen, 40,
                    class_1713.field_7791, client.field_1724);
        } else {
            doSwap(client, syncId, srcScreen, tgtSlot, handler);
        }

        return new PairResult(new class_1799(toEquip), toEquip.method_63680().getString());
    }

    private static void doSwap(class_310 c, int syncId, int src, int dst,
                               class_1723 h) {
        c.field_1761.method_2906(syncId, src, 0, class_1713.field_7790, c.field_1724);
        c.field_1761.method_2906(syncId, dst, 0, class_1713.field_7790, c.field_1724);
        if (!h.method_34255().method_7960())
            c.field_1761.method_2906(syncId, src, 0, class_1713.field_7790, c.field_1724);
    }

    private static class_1792 resolve(String id) {
        if (id == null || id.isEmpty() || "minecraft:air".equals(id)) return null;
        try { return class_7923.field_41178.method_63535(class_2960.method_60654(id)); } catch (Exception e) { return null; }
    }
    private static int findSlot(class_1661 inv, class_1792 item) {
        for (int i = 0; i < 36; i++) if (inv.method_5438(i).method_31574(item)) return i;
        return -1;
    }
    private static int invToScreen(int i) { return i < 9 ? 36 + i : i; }
}