package org.funtown.autoswap.swap;

import org.funtown.autoswap.config.AutoSwapConfig;
import org.funtown.autoswap.config.SwapEntry;
import org.funtown.autoswap.config.SwapPair;
import org.funtown.autoswap.hud.SwapHud;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import net.minecraft.class_1661;
import net.minecraft.class_1713;
import net.minecraft.class_1723;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_7923;

public class SwapExecutor {

    private enum State { IDLE, SWAPPING }

    private static final Random RANDOM = new Random();

    private static State state = State.IDLE;

    private static final ArrayDeque<SwapPair> queue = new ArrayDeque<>();
    private static int             waitTicks    = 0;
    private static long            lastSwapTime = 0L;

    private static int  step        = 0;
    private static int  src         = -1;
    private static int  dst         = -1;
    private static class_1792 toEquip     = null;
    private static boolean offhandMode = false;

    private static final List<class_1799> hudIcons = new ArrayList<>();
    private static final List<String>    hudNames = new ArrayList<>();

    public static void schedule(List<SwapEntry> entries) {
        if (state != State.IDLE || entries.isEmpty()) return;
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null) return;

        if (client.field_1724.field_7512 != client.field_1724.field_7498) return;

        if (System.currentTimeMillis() - lastSwapTime < nextCooldown()) return;

        queue.clear();
        for (SwapEntry entry : entries)
            for (SwapPair pair : entry.pairs) queue.add(pair);
        hudIcons.clear();
        hudNames.clear();
        step = 0;
        waitTicks = nextStepDelay();
        state = State.SWAPPING;
    }

    public static void tick(class_310 client) {
        if (state == State.IDLE || client.field_1724 == null) return;

        if (client.field_1724.field_7512 != client.field_1724.field_7498) {
            abort();
            return;
        }

        if (--waitTicks > 0) return;
        stepSwap(client);
    }

    private static void stepSwap(class_310 client) {
        if (step == 0) {
            SwapPair pair = queue.poll();
            if (pair == null) { finish(); return; }
            startPair(client, pair);
            if (step != 0) waitTicks = nextStepDelay();
            return;
        }

        class_1723 handler = client.field_1724.field_7498;
        int syncId = handler.field_7763;

        if (step == 1) {
            if (offhandMode) {
                client.field_1761.method_2906(syncId, src, 40, class_1713.field_7791, client.field_1724);
                recordHud();
                step = 0;
            } else {
                client.field_1761.method_2906(syncId, src, 0, class_1713.field_7790, client.field_1724);
                step = 2;
            }
            waitTicks = nextStepDelay();
            return;
        }
        if (step == 2) {
            client.field_1761.method_2906(syncId, dst, 0, class_1713.field_7790, client.field_1724);
            step = 3;
            waitTicks = nextStepDelay();
            return;
        }
        if (!handler.method_34255().method_7960())
            client.field_1761.method_2906(syncId, src, 0, class_1713.field_7790, client.field_1724);
        recordHud();
        step = 0;
        if (queue.isEmpty()) { finish(); return; }
        waitTicks = nextStepDelay();
    }

    private static void startPair(class_310 client, SwapPair pair) {
        class_1792 itemA = resolve(pair.itemId);
        class_1792 itemB = resolve(pair.itemId2);
        if (itemA == null && itemB == null) return;

        class_1661 inv     = client.field_1724.method_31548();
        int             tgtSlot = pair.targetSlot.screenSlot;
        class_1799       inSlot  = client.field_1724.field_7498.method_7611(tgtSlot).method_7677();

        boolean aOn = itemA != null && !inSlot.method_7960() && inSlot.method_31574(itemA);
        boolean bOn = itemB != null && !inSlot.method_7960() && inSlot.method_31574(itemB);

        int srcInv = -1;
        toEquip = null;

        if (aOn) {
            if (itemB == null) return;
            srcInv  = findSlot(inv, itemB);
            toEquip = itemB;
            if (srcInv == -1) { SwapHud.showNotFound(name(itemB)); return; }
        } else if (bOn) {
            if (itemA == null) return;
            srcInv  = findSlot(inv, itemA);
            toEquip = itemA;
            if (srcInv == -1) { SwapHud.showNotFound(name(itemA)); return; }
        } else {
            if (itemA != null) { srcInv = findSlot(inv, itemA); toEquip = itemA; }
            if (srcInv == -1 && itemB != null) { srcInv = findSlot(inv, itemB); toEquip = itemB; }
            if (srcInv == -1) {
                SwapHud.showNotFound(name(itemA != null ? itemA : itemB));
                return;
            }
        }

        src = invToScreen(srcInv);
        dst = tgtSlot;
        offhandMode = pair.targetSlot == TargetSlot.OFFHAND;
        step = 1;
    }

    private static void recordHud() {
        hudIcons.add(new class_1799(toEquip));
        hudNames.add(name(toEquip));
    }

    private static void finish() {
        if (!hudIcons.isEmpty() && AutoSwapConfig.getInstance().settings.showActionBar)
            SwapHud.showSuccess(hudIcons, hudNames);
        queue.clear();
        step = 0;
        lastSwapTime = System.currentTimeMillis();
        state = State.IDLE;
    }

    private static void abort() {
        queue.clear();
        hudIcons.clear();
        hudNames.clear();
        step = 0;
        state = State.IDLE;
    }

    private static int nextStepDelay() {
        int base = Math.max(1, AutoSwapConfig.getInstance().settings.stepDelayTicks);
        return base + RANDOM.nextInt(2);
    }

    private static long nextCooldown() {
        int ms = Math.max(0, AutoSwapConfig.getInstance().settings.swapCooldownMs);
        return ms == 0 ? 0L : ms + RANDOM.nextInt(Math.max(1, ms / 2));
    }

    private static class_1792 resolve(String id) {
        if (id == null || id.isEmpty() || "minecraft:air".equals(id)) return null;
        try {
            class_1792 item = class_7923.field_41178.method_63535(class_2960.method_60654(id));
            return item == class_1802.field_8162 ? null : item;
        } catch (Exception e) { return null; }
    }
    private static String name(class_1792 item) {
        return item.method_63680().getString();
    }
    private static int findSlot(class_1661 inv, class_1792 item) {
        for (int i = 0; i < 36; i++) if (inv.method_5438(i).method_31574(item)) return i;
        return -1;
    }
    private static int invToScreen(int i) { return i < 9 ? 36 + i : i; }
}
