package org.funtown.autoswap.swap;

import net.minecraft.class_10192;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_9334;

public class SlotDetector {

    public static TargetSlot detectSlot(class_1792 item) {
        class_1799 stack = new class_1799(item);
        class_10192 equippable = stack.method_57824(class_9334.field_54196);

        if (equippable != null) {
            return switch (equippable.comp_3174()) {
                case field_6169    -> TargetSlot.HELMET;
                case field_6174   -> TargetSlot.CHESTPLATE;
                case field_6172    -> TargetSlot.LEGGINGS;
                case field_6166    -> TargetSlot.BOOTS;
                case field_6171 -> TargetSlot.OFFHAND;
                default      -> TargetSlot.OFFHAND;
            };
        }

        
        return TargetSlot.OFFHAND;
    }
}