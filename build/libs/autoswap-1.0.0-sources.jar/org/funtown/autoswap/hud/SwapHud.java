package org.funtown.autoswap.hud;

import com.mojang.blaze3d.systems.RenderSystem;
import org.funtown.autoswap.config.ModTranslation;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_9779;

public class SwapHud {

    private record Entry(class_1799 icon, String text, int rgb) {}

    private static final List<Entry> entries   = new ArrayList<>();
    private static int               ticksLeft = 0;

    private static final int HOLD_TICKS  = 50;
    private static final int FADE_TICKS  = 20;
    private static final int TOTAL_TICKS = HOLD_TICKS + FADE_TICKS;

    public static void showSuccess(List<class_1799> icons, List<String> names) {
        entries.clear();
        for (int i = 0; i < Math.min(icons.size(), names.size()); i++) {
            String text = (i == 0 ? "" : "") + names.get(i);
            entries.add(new Entry(icons.get(i), text, 0xFFFF55));
        }
        ticksLeft = TOTAL_TICKS;
    }

    public static void showNotFound(String itemName) {
        entries.clear();
        String template = ModTranslation.get("autoswap.hud.not_found");
        String msg = template.contains("%s") ? template.replace("%s", itemName)
                : itemName + " — " + template;
        entries.add(new Entry(class_1799.field_8037, "✗ " + msg, 0xFF5555));
        ticksLeft = TOTAL_TICKS;
    }

    public static void tick() {
        if (ticksLeft > 0) ticksLeft--;
    }

    public static void render(class_332 context, class_9779 tickCounter) {
        if (ticksLeft <= 0 || entries.isEmpty()) return;

        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || client.field_1690.field_1842) return;

        float alpha   = ticksLeft <= FADE_TICKS ? (float) ticksLeft / FADE_TICKS : 1f;
        int   a       = Math.max(4, (int)(alpha * 255));

        class_327 tr      = client.field_1772;
        int          screenW = context.method_51421();
        int          screenH = context.method_51443();
        int          baseY   = screenH - 56;
        int          iconSize = 16;
        int          iconGap  = 3;
        String       sep      = "  |  ";
        int          sepW     = tr.method_1727(sep);

        int totalW = 0;
        for (int i = 0; i < entries.size(); i++) {
            Entry e = entries.get(i);
            if (!e.icon().method_7960()) totalW += iconSize + iconGap;
            totalW += tr.method_1727(e.text());
            if (i < entries.size() - 1) totalW += sepW;
        }

        int x     = (screenW - totalW) / 2;
        int iconY = baseY + (tr.field_2000 / 2) - (iconSize / 2);

        for (int i = 0; i < entries.size(); i++) {
            Entry e = entries.get(i);

            if (!e.icon().method_7960()) {
                RenderSystem.setShaderColor(1f, 1f, 1f, alpha);
                context.method_51427(e.icon(), x, iconY);
                RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
                x += iconSize + iconGap;
            }

            context.method_51433(tr, e.text(), x, baseY,
                    (a << 24) | (e.rgb() & 0x00FFFFFF), true);
            x += tr.method_1727(e.text());

            if (i < entries.size() - 1) {
                context.method_51433(tr, sep, x, baseY,
                        (a << 24) | 0x888888, true);
                x += sepW;
            }
        }
    }
}